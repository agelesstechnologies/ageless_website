@extends('layouts.app')

@section('content')
<style>
    .page-header {
        height:0px;
    }
</style>
<section class="page-header bd-bottom">
</section>
<section class="project-section padding">
    <div class="container">
        <div class="row gy-4">
            @forelse($products as $product)
                <div class="col-lg-4 col-md-6">
                    <a href="{{ route('products.show', $product->slug) }}" class="project-item d-block">
                        <div class="project-thumb">
                            <img src="{{ asset('storage/'.$product->image) }}" alt="{{ $product->name }}">
                        </div>

                        <div class="project-content">
                            <h3>{{ $product->name }}</h3>
                        </div>
                    </a>
                </div>
            @empty
                <div class="col-12">
                    <p>No products available.</p>
                </div>
            @endforelse
        </div>
    </div>
</section>

@endsection