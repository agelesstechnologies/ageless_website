@extends('layouts.app')

@section('content')

<section class="page-header bd-bottom">
    <div class="page-header-bg"></div>
    <div class="container">
        <div class="page-header-info">
            <h4>Product Details</h4>
            <h2>{{ $product->name }}</h2>
        </div>
    </div>
</section>
<style>
    .page-header {
        height:0px;
    }
</style>
<section class="project-details-section padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 sm-padding">
                @if($product->image)
                    <img src="{{ asset('storage/'.$product->image) }}" alt="{{ $product->name }}" class="img-fluid rounded">
                @endif
            </div>

            <div class="col-lg-6 sm-padding">
                <h2>{{ $product->name }}</h2>

                @if($product->short_description)
                    <p>{{ $product->short_description }}</p>
                @endif

                <div class="mt-4">
                    {!! nl2br(e($product->description)) !!}
                </div>

                <a href="{{ url('/contact') }}" class="default-btn mt-4">Enquire Now</a>
            </div>
        </div>
    </div>
</section>

@endsection