    <!doctype html>
    <html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="ThemeEaster">

        <title>Ageless</title>

        <link rel="shortcut icon" type="image/x-icon" href="{{ asset("assets/img/favicon.png") }}">
        <link href="https://fonts.googleapis.com/css2?family=Anton&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="{{ asset("assets/css/bootstrap.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/animate.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/keyframe-animation.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/line-awesome.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/construction-icons.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/odometer.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/nice-select.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/swiper.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/venobox.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/slider.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/common-style.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/main.css") }}">

    </head>

    <body>
        <div class="site-preloader">
            <div class="spinner"></div>
        </div>

        <!-- Site Preloader -->
  <header class="main-header">
            <div class="container">
                <div class="main-header-wapper">
                    <div class="site-logo">
                        <a href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="Logo"></a>
                    </div>
                    <div class="main-header-info">
                        <div class="top-header">
                            <ul class="top-left">
                                <li><i class="las la-phone-volume"></i><a href="tel:+917025777755">+91 7025 777 755</a></li>
                                <li><i class="las la-envelope-open"></i>info@agelessind.com</li>
                            </ul>
                            <div class="top-right">
                                <ul class="top-header-nav">
                                    <li><a href="{{ url('/faq') }}">FAQ</a></li>
                                </ul>
                                <ul class="header-social-share">

                                    <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                    <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                                    <li><a href="#"><i class="lab la-whatsapp"></i></a></li>

                                </ul>
                            </div>
                        </div>
                        <!--/.top-header-->
                        <div class="header-menu-wrap">
                            <ul class="nav-menu">
                                <li>
                                    <a href="{{ url('/') }}">Home</a>
                                </li>
                                <li>
                                    <a href="{{ url('/about-company') }}">About Us</a>
                                </li>
                                
                                <li>
                                    <a href="{{ url('/projects') }}">Projects</a>
                                    
                                </li>
                                <li>
                                    <a href="{{ url('/products') }}">Products</a>
                                    
                                </li>
                                <li class="dropdown_menu">
                                    <a href="{{ route('blog.index') }}">Blog</a>
                                </li>
                                <li><a href="{{ url('/contact') }}">Contact</a></li>
                            </ul>
                            <div class="menu-right-item">
                                <div class="mobile-menu-icon">
                                    <div class="burger-menu">
                                        <div class="line-menu line-half first-line"></div>
                                        <div class="line-menu"></div>
                                        <div class="line-menu line-half last-line"></div>
                                    </div>
                                </div>
                         
                            </div>
                        </div>
                        <!--/.header-menu-wrap-->
                    </div>
                </div>
            </div>
        </header>
        <!--/.main-header-->

        <div id="popup-search-box">
            <div class="box-inner-wrap d-flex align-items-center">
                <form id="form" action="#" method="get" role="search">
                    <input id="popup-search" type="text" name="s" placeholder="Type keywords here...">
                    <button id="popup-search-button" type="submit" name="submit">
                        <i class="las la-search"></i>
                    </button>
                </form>
                <div class="search-close"><i class="las la-times"></i></div>
            </div>
        </div>
        <!--/.popupsearch-box-->
<!-- ✅ ADD hero-section CLASS HERE -->
    <section class="page-header bd-bottom hero-section">
        <div class="page-header-bg"></div>
        <div class="container">
            <div class="page-header-info">
                <p class="dream-script">Build your</p>
                <h2 class="dream-title">
                    <span class="dream-white">DREAM</span>
                    <span class="dream-orange">PARK</span>
                    <span class="dream-white small">TODAY!</span>
                </h2>
            </div>
        </div>
    </section>

<style>
/* ✅ BACKGROUND IMAGE NOW WORKS */
.hero-section {
    position: relative;
    min-height: 100vh;
    display: flex;
    align-items: center;
    background: linear-gradient(
            90deg,
            rgba(3, 13, 40, 0.92) 0%,
            rgba(3, 13, 40, 0.75) 30%,
            rgba(3, 13, 40, 0.15) 65%,
            rgba(3, 13, 40, 0.05) 100%
        ),
        /* 🔄 REPLACE WITH YOUR IMAGE PATH */
        url(/hdr1.png) center center / cover no-repeat fixed;
    overflow: hidden;
}

/* Keep all other animations exactly the same */
.page-header-bg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, transparent 30%, rgba(245,161,0,0.1) 50%, transparent 70%);
    animation: shimmer 6s ease-in-out infinite;
    z-index: 1;
}

@keyframes shimmer {
    0%, 100% { transform: translateX(-100%) skewX(-15deg); opacity: 0; }
    50% { opacity: 1; }
    100% { transform: translateX(100%) skewX(-15deg); opacity: 0; }
}

.page-header-info {
    position: relative;
    z-index: 2;
    max-width: 600px;
    padding: 60px 0;
    animation: fadeInUp 1.2s ease-out 0.3s both;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    .dream-script {
        position: absolute;
        top: -30px;
        left: 10px;
        font-family: "Brush Script MT", "Segoe Script", cursive;
        font-size: 72px;
        line-height: 1;
        color: #ffffff !important;
        font-weight: 400;
        z-index: 3;
        text-shadow: 0 3px 10px rgba(0,0,0,0.35);
        opacity: 0;
        transform: translateY(-20px) scale(0.9);
        animation: scriptFloat 2s ease-out 0.8s both;
    }

@keyframes scriptFloat {
    0% {
        opacity: 0;
        transform: translateY(-20px) scale(0.9);
    }
    50% {
        transform: translateY(-5px) scale(1.05);
    }
    100% {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

.dream-title {
    margin: 0;
    line-height: 0.9;
    text-transform: uppercase;
    font-family: "Anton", "Arial Black", sans-serif;
    letter-spacing: 1px;
}

.dream-title span {
    display: block;
    opacity: 0;
    transform: translateX(-50px);
}

.dream-white {
    font-size: 100px;
    font-weight: 700;
    color: #ffffff !important;
    text-shadow: 0 5px 18px rgba(0,0,0,0.35);
    animation: slideInLeft 1s ease-out 1.2s both;
}

@keyframes slideInLeft {
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.dream-orange {
    font-size: 100px;
    font-weight: 700;
    color: #f5a100;
    text-shadow: 0 5px 18px rgba(0,0,0,0.35);
    animation: slideInRight 1s ease-out 1.6s both;
}

@keyframes slideInRight {
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.dream-title .small {
    font-size: 62px;
    margin-top: 12px;
    animation: bounceIn 1.2s ease-out 2s both;
}

@keyframes bounceIn {
    0% {
        opacity: 0;
        transform: scale(0.3) translateY(30px);
    }
    50% {
        transform: scale(1.05);
    }
    70% {
        transform: scale(0.98);
    }
    100% {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

/* Hover effects */
.dream-script:hover {
    animation: scriptGlow 0.6s ease-in-out;
}

@keyframes scriptGlow {
    0%, 100% { 
        text-shadow: 0 3px 10px rgba(0,0,0,0.35), 0 0 20px rgba(255,255,255,0.3);
    }
    50% { 
        text-shadow: 0 3px 10px rgba(0,0,0,0.35), 0 0 40px rgba(255,255,255,0.6);
    }
}

.dream-white:hover,
.dream-orange:hover {
    animation: titlePulse 0.8s ease-in-out;
}

@keyframes titlePulse {
    0%, 100% { 
        transform: scale(1);
        text-shadow: 0 5px 18px rgba(0,0,0,0.35);
    }
    50% { 
        transform: scale(1.02);
        text-shadow: 0 5px 18px rgba(0,0,0,0.35), 0 0 30px currentColor;
    }
}

/* Responsive */
@media (max-width: 991px) {
    .dream-script {
        font-size: 42px;
        top: 10px;
    }
    .dream-white {
        font-size: 75px;
    }
    .dream-orange {
        font-size: 82px;
    }
    .dream-title .small {
        font-size: 42px;
    }
    .hero-section {
        background-attachment: scroll !important;
    }
}

@media (max-width: 576px) {
    .page-header-info {
        padding: 30px 0;
    }
    .dream-script {
        font-size: 34px;
        top: -10px;
    }
    .dream-white {
        font-size: 52px;
    }
    .dream-orange {
        font-size: 58px;
    }
    .dream-title .small {
        font-size: 30px;
    }
}
</style>
    <!--/.slider-section-->
    <section class="about-section bd-bottom padding" style="padding-top: 26px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="about-img-wrap">
                            <img class="wow fade-in-bottom" data-wow-delay="200ms" src="{{ asset("assets/img/5001.png") }}" alt="img">
                            <img class="wow fade-in-right" data-wow-delay="400ms" src="{{ asset("assets/img/4001.png") }}" alt="img">
                            <div class="experience wow fade-in-bottom" data-wow-delay="500ms">
                            <h3>14+ <span>years of <br> experience</span></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="section-heading wow fade-in-bottom" data-wow-delay="200ms">
                        <h3>Welcome to Ageless Entertainments</h3>
                        <h2>India's Leading Amusement Park  <span>Developers Since 2011</span></h2>
                        <p>Ageless Entertainments is a leading name in the amusement industry, specializing in amusement rides, adventure rides,
                             immersive attractions, and other entertainment concepts. With a presence throughout India, we have successfully installed 
                             100+ park rides and activities in amusement parks, malls, and leisure destinations From concept to execution, we bring world
                             -class entertainment solutions that create unforgettable experiences for all ages!</p>
                    </div>
                    <ul class="about-features">
                        <li class="wow fade-in-bottom" data-wow-delay="200ms">
                            <div class="about-icon">
                                <i class="ci ci-excavators"></i>
                            </div>
                            <div class="about-features-content">
                                <h3>Quality Services</h3>
                                <p>Committed to excellence in every park we build.</p>
                            </div>
                        </li>
                        <li class="wow fade-in-bottom" data-wow-delay="400ms">
                            <div class="about-icon">
                                <i class="ci ci-engineer-2"></i>
                            </div>
                            <div class="about-features-content">
                                <h3>Skilled Developers</h3>
                                <p>We design and build all kinds of parks.</p>
                            </div>
                        </li>
                    </ul>
                    <div class="btn-group">
                        <a href="{{ url('/about') }}" class="default-btn wow fade-in-bottom" data-wow-delay="200ms">More About Us</a>
                        <div class="about-author wow fade-in-bottom" data-wow-delay="400ms">
                            <img src="https://assets.zyrosite.com/cdn-cgi/image/format=auto,w=375,h=351,fit=crop/AGBM0Vqo2Ripq5Zk/393083348_1179677340102907_7185821607908418361_n-removebg-preview-Yan1N0zwyWcZ74pv.png" alt="thumb">
                            <h3>Proud Member of IAAPI Since 2015</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/.about-section-->

    <section class="service-section padding">
        <div class="bg-half"></div>
        <div class="container">
            <div class="section-heading text-center mb-40 wow fade-in-bottom" data-wow-delay="200ms">
                <h3>Explore our park creation services!</h3>
                <h2>Building fun worlds with <br><span>imagination and joy!</span></h2>
                <p>We design, build, and bring to life thrilling amusement parks, <br> rides, and family attractions with creativity and precision.</p>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 sm-padding">
                    <div class="service-item wow fade-in-bottom" data-wow-delay="200ms">
                        <div class="service-item-inner">
                            <div class="service-thumb">
                                <img src="{{ asset("assets/img/amu.png") }}" alt="thumb">
                            </div>
                            <div class="service-content">
                                <div class="service-icon">
                                    <i class="ci ci-tools"></i>
                                </div>
                                <h3>Amusement Park Rides</h3>
                                  <p>Safe, colorful, and eco-friendly trains that bring joy to every corner of your park.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 sm-padding">
                    <div class="service-item wow fade-in-bottom" data-wow-delay="400ms">
                        <div class="service-item-inner">
                            <div class="service-thumb">
                                <img src="{{ asset("assets/img/traffic.png") }}" alt="thumb">
                            </div>
                            <div class="service-content">
                                <div class="service-icon">
                                    <i class="ci ci-tools"></i>
                                </div>
                                <h3>Traffic Park Vehicles</h3>
                                 <p>Interactive vehicles designed for kids and adults to learn and enjoy safe driving fun.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 sm-padding">
                    <div class="service-item wow fade-in-bottom" data-wow-delay="600ms">
                        <div class="service-item-inner">
                            <div class="service-thumb">
                                <img src="{{ asset("assets/img/water.png") }}" alt="thumb">
                            </div>
                            <div class="service-content">
                                <div class="service-icon">
                                    <i class="ci ci-tools"></i>
                                </div>
                                 <h3>Water Park Attractions</h3>
                                  <p>From splash rides to lazy rivers, we build aquatic adventures for all ages.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 sm-padding">
                    <div class="service-item wow fade-in-bottom" data-wow-delay="800ms">
                        <div class="service-item-inner">
                            <div class="service-thumb">
                                <img src="{{ asset("assets/img/adventure.png") }}" alt="thumb">
                            </div>
                            <div class="service-content">
                                <div class="service-icon">
                                    <i class="ci ci-tools"></i>
                                </div>
                                <h3>Sky and Adventure Rides</h3>
                                 <p>Exciting rides that lift the fun to new heights — from monorails to sky gliders.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="service-cta">
                <div class="service-cta-inner">
                    <h4>Offering High Quality Parks!</h4>
                    <a class="default-btn" href="https://wa.me/+917025777755">Make an Appointment</a>
                </div>
            </div>
        </div>
    </section>

    <!--/.service-section-->
    <section class="skill-section bd-bottom padding-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="skill-img-wrap wow fade-in-bottom" data-wow-delay="200ms">
                        <img class="skill-img" src="{{ asset("assets/img/3d1.png") }}" alt="">
                        <a class="play-btn venobox wow swing center" data-vbtype="video" href="https://www.youtube.com/watch?v=ZLaG1migE00">
                            <span class="play-icon">
                                <svg aria-hidden="true" focusable="false" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor" d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                </svg>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="section-heading mb-30 wow fade-in-bottom" data-wow-delay="200ms">
                        <h3>Great experience in building!</h3>
                        <h2>Manage everything for brand and <span>trademark!</span></h2>
                        <p>Construction is a general term meaning the art and science to form <br>objects systems or organizations.</p>
                    </div>
                    <ul class="skill-wrap mb-40 wow fade-in-bottom" data-wow-delay="400ms">
                        <li class="skill-item">
                            <h4>Factory Manufacture</h4>
                            <div class="progress-box">
                                <div class="progress">
                                    <div class="progress-bar wow progress-bar-anim" data-wow-delay="0ms" data-wow-duration="2000ms" role="progressbar" style="--progress-bar-count: 85%">
                                        <span>85%</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="skill-item">
                            <h4>General Construction</h4>
                            <div class="progress-box">
                                <div class="progress">
                                    <div class="progress-bar wow progress-bar-anim" data-wow-delay="200ms" data-wow-duration="2000ms" role="progressbar" style="--progress-bar-count: 75%">
                                        <span>75%</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="skill-item">
                            <h4>Architecture Planing</h4>
                            <div class="progress-box">
                                <div class="progress">
                                    <div class="progress-bar wow progress-bar-anim" data-wow-delay="200ms" data-wow-duration="2000ms" role="progressbar" style="--progress-bar-count: 95%">
                                        <span>95%</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <a class="default-btn wow fade-in-bottom" data-wow-delay="200ms" href="{{ url('/about') }}">More About Us</a>
                </div>
            </div>
        </div>
    </section>
    <!--/.video-box-->

    <section class="project-section bg-grey padding">
        <div class="bg-pattern"></div>
        <div class="container">
            <div class="section-heading-wrap mb-40">
                <div class="section-heading wow fade-in-left" data-wow-delay="200ms">
                    <h3>Discover our projects</h3>
                    <h2>Work together to create <br>unique <span>experience!</span></h2>
                    
                </div>
                <a class="default-btn wow fade-in-right" data-wow-delay="400ms" href="{{ url('/projects') }}">View All Project</a>
            </div>
            <div class="swiper-outside">
                <div class="project-carousel">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="200ms">
                                <div class="project-thumb project-view">
                                    <a class="venobox" href="https://img.onmanorama.com/content/dam/mm/en/archive/travel/kerala/images/2025/7/27/dome-theatre.jpg" data-gall="projects"><img src="https://img.onmanorama.com/content/dam/mm/en/archive/travel/kerala/images/2025/7/27/dome-theatre.jpg" alt="img"></a>
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Dome Cinema</a>
                                    <h3><a href="{{ url('/dome-cinema') }}">Munnar Botanical Garden </a></h3>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="400ms">
                                <div class="project-thumb project-view">
                                    <a class="venobox" href="" data-gall="projects"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThMNV5dUkiziBpjzk2FnGZ1GE4m6CzHg8ynw&s" alt="img"></a>
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Interactive & Immersive Room</a>
                                    <h3><a href="{{ url('/interactive-room') }}">Hilite Mall at Calicut </a></h3>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="600ms">
                                <div class="project-thumb project-view">
                                    <a class="venobox" href="{{ asset("assets/img/project-3.jpg") }}" data-gall="projects"><img src="https://kidsloveqatar.com/wp-content/uploads/2026/01/Fly-Over-Wonders-4.webp  " alt="img"></a>
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Flying Cinema</a>
                                    <h3><a href="{{ url('/flying-cinema') }}">Mall of Qatar</a></h3>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="700ms">
                                <div class="project-thumb project-view">
                                    <a class="venobox" href="{{ asset("assets/img/project-4.jpg") }}" data-gall="projects"><img src="https://5.imimg.com/data5/SELLER/Default/2025/7/523820546/HZ/TF/XC/27654362/rope-rider.jpg" alt="img"></a>
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Rope Rider</a>
                                    <h3><a href="{{ url('/rope-rider') }}">Misty Land Malappuram</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-pagination"></div><!-- Carousel Dots -->
                </div>
                <!-- Carousel Arrows -->
                <div class="swiper-nav swiper-next"><i class="las la-long-arrow-alt-right"></i></div>
                <div class="swiper-nav swiper-prev"><i class="las la-long-arrow-alt-left"></i></div>
            </div>
        </div>
    </section>
    <!--/.project-section-->

    <!--/.team-section-->
    <section class="counter-section overflow-hidden">
        <div class="container">
            <div class="row counter-wrap gy-lg-0 gy-4">
                <div class="square-pattern"></div>
                <div class="col-lg-3 col-md-6 wow fade-in-bottom" data-wow-delay="200ms">
                    <div class="counter-item">
                        <div class="counter-icon">
                            <i class="ci ci-engineer-2"></i>
                        </div>
                        <div class="counter-content">
                            <h3><span class="odometer" data-count="200">00</span></h3>
                            <h4>Happy Clients</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fade-in-bottom" data-wow-delay="400ms">
                    <div class="counter-item">
                        <div class="counter-icon">
                            <i class="ci ci-building"></i>
                        </div>
                        <div class="counter-content">
                            <h3><span class="odometer" data-count="250">00</span></h3>
                            <h4>Project Completed</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fade-in-bottom" data-wow-delay="600ms">
                    <div class="counter-item">
                        <div class="counter-icon">
                            <i class="ci ci-hand"></i>
                        </div>
                        <div class="counter-content">
                            <h3><span class="odometer" data-count="70">00</span></h3>
                            <h4>Award Won</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fade-in-bottom" data-wow-delay="800ms">
                    <div class="counter-item">
                        <div class="counter-icon">
                            <i class="ci ci-engineer"></i>
                        </div>
                        <div class="counter-content">
                            <h3><span class="odometer" data-count="500">00</span></h3>
                            <h4>Team Members</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!--/.testimonial-section-->

    <!--/.cta-section-->
    <div class="sponsor-section">
        <div class="container">
            <div class="outside-spacing">
                <div class="sponsor-carousel">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor01.png") }}" alt="img"></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor02.png") }}" alt="img"></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor03.png") }}" alt="img"></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor04.png") }}" alt="img"></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor05.png") }}" alt="img"></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="{{ asset("assets/img/sponsor06.png") }}" alt="img"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/.sponsor-carousel-->


<!-- WhatsApp and Call Buttons -->

<div class="floating-buttons">
  <a href="https://wa.me/+917025777755" class="whatsapp" target="_blank">
    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp">
  </a>
  <a href="tel:+917025777755" class="call" target="_blank">
    <span class="ring-circle"></span>
    <img src="https://cdn-icons-png.flaticon.com/512/724/724664.png" alt="Call">
  </a>
</div>

<style>
.floating-buttons {
  position: fixed;
  bottom: 20px;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
  z-index: 1000;
}

/* Base button */
.floating-buttons a {
  position: relative;
  display: inline-flex;
  justify-content: center;
  align-items: center;
}

/* WhatsApp */
.whatsapp img {
  width: 55px;
  height: 55px;
  border-radius: 50%;
  box-shadow: 0 0 15px rgba(37, 211, 102, 0.6);
  transition: transform 0.3s ease;
}
.whatsapp img:hover {
  transform: scale(1.15);
}

/* Call Button */
.call {
  position: relative;
  width: 55px;
  height: 55px;
}
.call img {
  width: 55px;
  height: 55px;
  border-radius: 50%;
  background: #00bfff;
  box-shadow: 0 0 15px rgba(0, 191, 255, 0.8);
  animation: ring 1.5s infinite ease-in-out;
}

/* Ripple effect around call button */
.call .ring-circle {
  position: absolute;
  width: 75px;
  height: 75px;
  border: 2px solid rgba(0,191,255,0.5);
  border-radius: 50%;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation: ripple 1.5s infinite ease-out;
}

/* Phone ring shake animation */
@keyframes ring {
  0% { transform: rotate(0deg); }
  10% { transform: rotate(15deg); }
  20% { transform: rotate(-10deg); }
  30% { transform: rotate(10deg); }
  40% { transform: rotate(-5deg); }
  50% { transform: rotate(5deg); }
  60%, 100% { transform: rotate(0deg); }
}

/* Ripple expansion animation */
@keyframes ripple {
  0% {
    transform: translate(-50%, -50%) scale(0.8);
    opacity: 0.8;
  }
  100% {
    transform: translate(-50%, -50%) scale(1.8);
    opacity: 0;
  }
}
</style>

<!-- end WhatsApp and Call Buttons -->
    <footer class="footer-section">
            <div class="container">
                <div class="row footer-area">
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <a class="footer-logo" href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="logo"></a>
                            <p>Our success in creating business solutions is due in part spacially to talented committed team.</p>
                            <ul class="footer-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-youtube"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Company</h3>
                            <ul class="footer-list">
                                <li><a href="{{ url('/about') }}">About Us</a></li>
                                <li><a href="{{ url('/contact') }}">Get in Touch</a></li>
                                <li><a href="{{ url('/faqs') }}">Help &amp; Faqs</a></li>
                                <li><a href="{{ url('/faqs') }}">Privacy Policy</a></li>
                                <li><a href="{{ url('/contact') }}">Support</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Information</h3>
                            <ul class="footer-list">
                                <li>
                                    <p>A.M.A Arcade, Vallathol Junction, 4/1585, Seaport - Airport Rd, P.O, Thrikkakara, Front, Kochi, Kakkanad, Kerala 682021</p>
                                </li>
                                <li><a href="tel:7025777755">+91 7025 777 755</a></li>
                                <li><a href="#">info@agelessind.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Subscribe Newslatters</h3>
                            <form action="php/mailchimp-subscribe.php" id="ajax_mc_form" class="subscribe-form">
                                <div class="mc-fields">
                                    <input id="mc_email" class="form-control" type="email" name="mc_email" placeholder="Your Email" required>
                                    <button class="submit"><i class="las la-long-arrow-alt-right"></i></button>
                                </div>
                                <div class="clearfix"></div>
                                <div id="mc-form-messages" class="alert" role="alert"></div>
                            </form>
                            <p>Subscribe us and get all the benifits from today.</p>
                        </div>
                    </div>
                </div>
                <div class="copyright-text">
                    © <span id="currentYear"></span> Ageless Entertainments All Rights Reserved.</a>
                </div>
            </div>
    </footer>
    <!--/.footer-section-->

    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>
    <!--/.scrollup-->

    <!--jQuery Lib-->
    <script src="{{ asset("assets/js/vendor/jquary-3.6.0.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/bootstrap.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/popper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/odometer.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/jquery.nice-select.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/waypoints.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/venobox.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/swiper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/smooth-scroll.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/wow.min.js") }}"></script>
    <script src="{{ asset("assets/js/mailchimp.js") }}"></script>
    <script src="{{ asset("assets/js/main.js") }}"></script>

</body>

</html>
