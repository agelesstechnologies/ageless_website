<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Buildex Construction and Building HTML5 Template">
    <meta name="author" content="ThemeEaster">

    <title>Buildex | Construction and Building HTML5 Template</title>

    <link rel="shortcut icon" type="image/x-icon" href="{{ asset("assets/img/favicon.png") }}">

    <link rel="stylesheet" href="{{ asset("assets/css/bootstrap.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/animate.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/keyframe-animation.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/line-awesome.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/construction-icons.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/odometer.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/nice-select.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/swiper.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/venobox.min.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/slider.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/common-style.css") }}">
    <link rel="stylesheet" href="{{ asset("assets/css/main.css") }}">

</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <div class="site-preloader">
        <div class="spinner"></div>
    </div>
    <!-- Site Preloader -->

    <header class="main-header">
        <div class="container">
            <div class="main-header-wapper">
                <div class="site-logo">
                    <a href="{{ url('/') }}"><img src="{{ asset("assets/img/logo-light.png") }}" alt="Logo" /></a>
                </div>
                <div class="main-header-info">
                    <div class="top-header">
                        <ul class="top-left">
                            <li><i class="las la-phone-volume"></i><a href="tel:5267214392">5267-214-392</a></li>
                            <li><i class="las la-envelope-open"></i>info.help@mail.Com</li>
                        </ul>
                        <div class="top-right">
                            <ul class="top-header-nav">
                                <li><a href="{{ url('/faqs') }}">Help</a></li>
                                <li><a href="{{ url('/contact') }}">Support</a></li>
                                <li><a href="{{ url('/faqs') }}">FAQ</a></li>
                            </ul>
                            <ul class="header-social-share">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-pinterest"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!--/.top-header-->
                    <div class="header-menu-wrap">
                        <ul class="nav-menu">
                            <li>
                                <a href="{{ url('/') }}">Home</a>
                                <ul>
                                    <li><a href="{{ url('/') }}">Home Default</a></li>
                                    <li><a href="{{ url('/index-2') }}">Home Modern</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="{{ url('/about-company') }}">Company</a>
                                <ul>
                                    <li><a href="{{ url('/about') }}">About Us</a></li>
                                    <li><a href="{{ url('/about-company') }}">About Company</a></li>
                                    <li><a href="{{ url('/services') }}"></a></li>
                                    <li><a href="{{ url('/services-details') }}">Services Details</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Pages</a>
                                <ul>
                                    <li><a href="{{ url('/team') }}">Our Team</a></li>
                                    <li><a href="{{ url('/team-details') }}">Team Details</a></li>
                                    <li><a href="{{ url('/testimonials') }}">Testimonials</a></li>
                                    <li><a href="{{ url('/faq') }}">Help &amp; Faq's</a></li>
                                    <li><a href="{{ url('/404') }}">404 Error</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="{{ url('/projects') }}">Projects</a>
                                <ul>
                                    <li><a href="{{ url('/projects') }}">Our Projects</a></li>
                                    <li><a href="{{ url('/project-details') }}">Project Details</a></li>
                                </ul>
                            </li>
                            <li class="dropdown_menu">
                                <a href="{{ route('blog.index') }}">Blog</a>
                                <ul>
                                    <li><a href="{{ route('blog.index') }}">Grid Posts</a></li>
                                    <li><a href="{{ url('/blog-classic') }}">Classic Posts</a></li>
                                    <li><a href="{{ route('blog.index') }}">Blog Details</a></li>
                                </ul>
                            </li>
                            <li><a href="{{ url('/contact') }}">Contact</a></li>
                        </ul>
                        <div class="menu-right-item">
                            <div class="menu-action-btn dl-search-icon">
                                <i class="las la-search"></i>
                            </div>
                            <div class="menu-action-btn cart">
                                <i class="las la-shopping-cart"></i>
                                <span>0</span>
                            </div>
                            <div class="mobile-menu-icon">
                                <div class="burger-menu">
                                    <div class="line-menu line-half first-line"></div>
                                    <div class="line-menu"></div>
                                    <div class="line-menu line-half last-line"></div>
                                </div>
                            </div>
                            <a href="{{ url('/contact') }}" class="default-btn d-none d-lg-block d-md-block">Get Solution</a>
                        </div>
                    </div>
                    <!--/.header-menu-wrap-->
                </div>
            </div>
        </div>
    </header>
    <!--/.main-header-->

    <div id="popup-search-box">
        <div class="box-inner-wrap d-flex align-items-center">
            <form id="form" action="#" method="get" role="search">
                <input id="popup-search" type="text" name="s" placeholder="Type keywords here...">
                <button id="popup-search-button" type="submit" name="submit">
                    <i class="las la-search"></i>
                </button>
            </form>
            <div class="search-close"><i class="las la-times"></i></div>
        </div>
    </div>
    <!--/.popupsearch-box-->
    <div id="searchbox-overlay"></div>

    <section class="page-header error">
        <div class="page-header-bg"></div>
        <div class="container">
            <div class="page-header-info text-center">
                <img src="{{ asset("assets/img/crying-emoji.svg") }}" alt="img">
                <h2>404 Page <span>Not Found!</span></h2>
                <p>The page you are looking for was moved, removed, <br> renamed or might never existed.</p>
                <a href="{{ url('/') }}" class="default-btn mt-20">Back To Home</a>
            </div>
        </div>
    </section>
    <!--page-header-->

   <footer class="footer-section">
            <div class="container">
                <div class="row footer-area">
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <a class="footer-logo" href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="logo"></a>
                            <p>Our success in creating business solutions is due in part spacially to talented committed team.</p>
                            <ul class="footer-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-youtube"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Company</h3>
                            <ul class="footer-list">
                                <li><a href="{{ url('/about') }}">About Us</a></li>
                                <li><a href="{{ url('/contact') }}">Get in Touch</a></li>
                                <li><a href="{{ url('/faqs') }}">Help &amp; Faqs</a></li>
                                <li><a href="{{ url('/faqs') }}">Privacy Policy</a></li>
                                <li><a href="{{ url('/contact') }}">Support</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Information</h3>
                            <ul class="footer-list">
                                <li>
                                    <p>A.M.A Arcade, Vallathol Junction, 4/1585, Seaport - Airport Rd, P.O, Thrikkakara, Front, Kochi, Kakkanad, Kerala 682021</p>
                                </li>
                                <li><a href="tel:7025777755">+91 7025 777 755</a></li>
                                <li><a href="#">info@agelessind.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Subscribe Newslatters</h3>
                            <form action="php/mailchimp-subscribe.php" id="ajax_mc_form" class="subscribe-form">
                                <div class="mc-fields">
                                    <input id="mc_email" class="form-control" type="email" name="mc_email" placeholder="Your Email" required>
                                    <button class="submit"><i class="las la-long-arrow-alt-right"></i></button>
                                </div>
                                <div class="clearfix"></div>
                                <div id="mc-form-messages" class="alert" role="alert"></div>
                            </form>
                            <p>Subscribe us and get all the benifits from today.</p>
                        </div>
                    </div>
                </div>
                <div class="copyright-text">
                    © <span id="currentYear"></span> Ageless Entertainments All Rights Reserved.</a>
                </div>
            </div>
    </footer>
    <!--/.footer-section-->

    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>
    <!-- /.scrollup -->

    <!--jQuery Lib-->
    <script src="{{ asset("assets/js/vendor/jquary-3.6.0.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/bootstrap.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/popper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/odometer.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/jquery.nice-select.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/waypoints.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/venobox.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/swiper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/smooth-scroll.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/wow.min.js") }}"></script>
    <script src="{{ asset("assets/js/mailchimp.js") }}"></script>
    <script src="{{ asset("assets/js/main.js") }}"></script>

</body>

</html>
