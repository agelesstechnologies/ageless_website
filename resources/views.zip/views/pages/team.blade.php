<!doctype html>
    <html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Buildex Construction and Building HTML5 Template">
        <meta name="author" content="ThemeEaster">

        <title>Agelessindia</title>

        <link rel="shortcut icon" type="image/x-icon" href="{{ asset("assets/img/favicon.png") }}">

        <link rel="stylesheet" href="{{ asset("assets/css/bootstrap.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/animate.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/keyframe-animation.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/line-awesome.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/construction-icons.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/odometer.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/nice-select.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/swiper.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/venobox.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/slider.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/common-style.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/main.css") }}">

    </head>

    <body>
        
        <div class="site-preloader">
            <div class="spinner"></div>
        </div>
        <!-- Site Preloader -->

       <header class="main-header">
            <div class="container">
                <div class="main-header-wapper">
                    <div class="site-logo">
                        <a href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="Logo"></a>
                    </div>
                    <div class="main-header-info">
                        <div class="top-header">
                            <ul class="top-left">
                                <li><i class="las la-phone-volume"></i><a href="tel:+917025777755">+91 7025 777 755</a></li>
                                <li><i class="las la-envelope-open"></i>info@agelessind.com</li>
                            </ul>
                            <div class="top-right">
                                <ul class="top-header-nav">
                                    <li><a href="{{ url('/faqs') }}">Help</a></li>
                                    <li><a href="{{ url('/faqs') }}">FAQ</a></li>
                                </ul>
                                <ul class="header-social-share">

                                    <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                    <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                                    <li><a href="#"><i class="lab la-whatsapp"></i></a></li>

                                </ul>
                            </div>
                        </div>
                        <!--/.top-header-->
                        <div class="header-menu-wrap">
                            <ul class="nav-menu">
                                <li>
                                    <a href="{{ url('/') }}">Home</a>
                                </li>
                                <li>
                                    <a href="{{ url('/about-company') }}">About Us</a>
                                </li>
                                
                                <li>
                                    <a href="{{ url('/projects') }}">Projects</a>
                                    
                                </li>
                                <li class="dropdown_menu">
                                    <a href="{{ route('blog.index') }}">Blog</a>
                                </li>
                                <li><a href="{{ url('/contact') }}">Contact</a></li>
                            </ul>
                            <div class="menu-right-item">
                                <div class="mobile-menu-icon">
                                    <div class="burger-menu">
                                        <div class="line-menu line-half first-line"></div>
                                        <div class="line-menu"></div>
                                        <div class="line-menu line-half last-line"></div>
                                    </div>
                                </div>
                         
                            </div>
                        </div>
                        <!--/.header-menu-wrap-->
                    </div>
                </div>
            </div>
        </header>
        <!--/.main-header-->

    <div id="popup-search-box">
        <div class="box-inner-wrap d-flex align-items-center">
            <form id="form" action="#" method="get" role="search">
                <input id="popup-search" type="text" name="s" placeholder="Type keywords here...">
                <button id="popup-search-button" type="submit" name="submit">
                    <i class="las la-search"></i>
                </button>
            </form>
            <div class="search-close"><i class="las la-times"></i></div>
        </div>
    </div>
    <!--/.popupsearch-box-->
    <div id="searchbox-overlay"></div>

    <section class="page-header bd-bottom">
        <div class="page-header-bg"></div>
        <div class="container">
            <div class="page-header-info">
                <h4>Our Dedicated Team</h4>
                <h2>Our team create great <br>things <span>together!</span></h2>
                <p>Our versatile team is built of designers, developers and <br>digital marketers who all bring unique experience.</p>
            </div>
        </div>
    </section>
    <!--page-header-->

    <section class="team-section padding">
        <div class="wave-line"></div>
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-1.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Site Engineer</h4>
                            <h3><a href="{{ url('/team-details') }}">Joseph Crawford</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-2.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Project Manager</h4>
                            <h3><a href="{{ url('/team-details') }}">Anthony Notson</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-3.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Structural Engineer</h4>
                            <h3><a href="{{ url('/team-details') }}">Allison Herman</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-4.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Executive Advisor</h4>
                            <h3><a href="{{ url('/team-details') }}">James Williams</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-5.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Executive Advisor</h4>
                            <h3><a href="{{ url('/team-details') }}">Kristin Castillo</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-6.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Structural Engineer</h4>
                            <h3><a href="{{ url('/team-details') }}">Stephen Miller</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-7.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Project Manager</h4>
                            <h3><a href="{{ url('/team-details') }}">Timothy Paradis</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="{{ asset("assets/img/team-8.jpg") }}" alt="thumb">
                            <ul class="team-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-twitter"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="team-content">
                            <h4 class="position">Site Engineer</h4>
                            <h3><a href="{{ url('/team-details') }}">Félix Lengyel</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/.team-section-->

    <section class="call-to-action padding-bottom">
        <div class="container">
            <div class="row">
                <div class="cta-inner">
                    <div class="section-heading">
                        <h3>Lets talk with us!</h3>
                        <h2>Serving since 1970 with <br> Global <span>strategies.</span></h2>
                    </div>
                    <div class="btn-wrap"><a href="#" class="default-btn">Get Solution</a></div>
                </div>
            </div>
        </div>
    </section>
    <!--/.cta-area-->

   <footer class="footer-section">
            <div class="container">
                <div class="row footer-area">
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <a class="footer-logo" href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="logo"></a>
                            <p>Our success in creating business solutions is due in part spacially to talented committed team.</p>
                            <ul class="footer-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-youtube"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Company</h3>
                            <ul class="footer-list">
                                <li><a href="{{ url('/about') }}">About Us</a></li>
                                <li><a href="{{ url('/contact') }}">Get in Touch</a></li>
                                <li><a href="{{ url('/faqs') }}">Help &amp; Faqs</a></li>
                                <li><a href="{{ url('/faqs') }}">Privacy Policy</a></li>
                                <li><a href="{{ url('/contact') }}">Support</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Information</h3>
                            <ul class="footer-list">
                                <li>
                                    <p>A.M.A Arcade, Vallathol Junction, 4/1585, Seaport - Airport Rd, P.O, Thrikkakara, Front, Kochi, Kakkanad, Kerala 682021</p>
                                </li>
                                <li><a href="tel:7025777755">+91 7025 777 755</a></li>
                                <li><a href="#">info@agelessind.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Subscribe Newslatters</h3>
                            <form action="php/mailchimp-subscribe.php" id="ajax_mc_form" class="subscribe-form">
                                <div class="mc-fields">
                                    <input id="mc_email" class="form-control" type="email" name="mc_email" placeholder="Your Email" required>
                                    <button class="submit"><i class="las la-long-arrow-alt-right"></i></button>
                                </div>
                                <div class="clearfix"></div>
                                <div id="mc-form-messages" class="alert" role="alert"></div>
                            </form>
                            <p>Subscribe us and get all the benifits from today.</p>
                        </div>
                    </div>
                </div>
                <div class="copyright-text">
                    © <span id="currentYear"></span> Ageless Entertainments All Rights Reserved.</a>
                </div>
            </div>
    </footer>
    <!--/.footer-section-->

    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>
    <!--/.scrollup-->

    <!--jQuery Lib-->
    <script src="{{ asset("assets/js/vendor/jquary-3.6.0.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/bootstrap.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/popper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/odometer.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/jquery.nice-select.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/waypoints.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/venobox.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/swiper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/smooth-scroll.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/wow.min.js") }}"></script>
    <script src="{{ asset("assets/js/mailchimp.js") }}"></script>
    <script src="{{ asset("assets/js/main.js") }}"></script>

</body>

</html>
