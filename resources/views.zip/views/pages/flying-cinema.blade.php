<!doctype html>
    <html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Buildex Construction and Building HTML5 Template">
        <meta name="author" content="ThemeEaster">

        <title>Agelessindia - Flying Cinema</title>

        <link rel="shortcut icon" type="image/x-icon" href="{{ asset("assets/img/favicon.png") }}">

        <link rel="stylesheet" href="{{ asset("assets/css/bootstrap.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/animate.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/keyframe-animation.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/line-awesome.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/construction-icons.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/odometer.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/nice-select.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/swiper.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/venobox.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/slider.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/common-style.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/main.css") }}">

    </head>

    <body>
        
        <div class="site-preloader">
            <div class="spinner"></div>
        </div>
        <!-- Site Preloader -->

       <header class="main-header">
            <div class="container">
                <div class="main-header-wapper">
                    <div class="site-logo">
                        <a href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="Logo"></a>
                    </div>
                    <div class="main-header-info">
                        <div class="top-header">
                            <ul class="top-left">
                                <li><i class="las la-phone-volume"></i><a href="tel:+917025777755">+91 7025 777 755</a></li>
                                <li><i class="las la-envelope-open"></i>info@agelessind.com</li>
                            </ul>
                            <div class="top-right">
                                <ul class="top-header-nav">
                                    <li><a href="{{ url('/faqs') }}">Help</a></li>
                                    <li><a href="{{ url('/faqs') }}">FAQ</a></li>
                                </ul>
                                <ul class="header-social-share">

                                    <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                    <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                                    <li><a href="#"><i class="lab la-whatsapp"></i></a></li>

                                </ul>
                            </div>
                        </div>
                        <!--/.top-header-->
                        <div class="header-menu-wrap">
                            <ul class="nav-menu">
                                <li>
                                    <a href="{{ url('/') }}">Home</a>
                                </li>
                                <li>
                                    <a href="{{ url('/about-company') }}">About Us</a>
                                </li>
                                
                                <li>
                                    <a href="{{ url('/projects') }}">Projects</a>
                                    
                                </li>
                                <li class="dropdown_menu">
                                    <a href="{{ route('blog.index') }}">Blog</a>
                                </li>
                                <li><a href="{{ url('/contact') }}">Contact</a></li>
                            </ul>
                            <div class="menu-right-item">
                                <div class="mobile-menu-icon">
                                    <div class="burger-menu">
                                        <div class="line-menu line-half first-line"></div>
                                        <div class="line-menu"></div>
                                        <div class="line-menu line-half last-line"></div>
                                    </div>
                                </div>
                         
                            </div>
                        </div>
                        <!--/.header-menu-wrap-->
                    </div>
                </div>
            </div>
        </header>
        <!--/.main-header-->

    <div id="popup-search-box">
        <div class="box-inner-wrap d-flex align-items-center">
            <form id="form" action="#" method="get" role="search">
                <input id="popup-search" type="text" name="s" placeholder="Type keywords here...">
                <button id="popup-search-button" type="submit" name="submit">
                    <i class="las la-search"></i>
                </button>
            </form>
            <div class="search-close"><i class="las la-times"></i></div>
        </div>
    </div>
    <!--/.popupsearch-box-->
    <div id="searchbox-overlay"></div>

    <section class="page-header bd-bottom">
        <div class="page-header-bg"></div>
        <div class="container">
            <div class="page-header-info text-center">
                <h4>Project details</h4>
                <h2>Flying <span>Cinema</span></h2>
                <p>Feel the thrill of flight combined with stunning cinematic visuals.</p>
            </div>
        </div>
    </section>
    <!--page-header-->

    <section class="project-info">
        <div class="container">
            <ul class="project-info-list">
                <li class="project-info-item">
                    <h3>Client Info:</h3>
                    <p>Mall of Qatar</p>
                </li>
                <li class="project-info-item">
                    <h3>Project Handover:</h3>
                    <p>Recently Completed</p>
                </li>
                <li class="project-info-item">
                    <h3>Services:</h3>
                    <p>Engineering, Synchronized Motion Seating, Visual Simulation</p>
                </li>
                <li class="project-info-item">
                    <h3>Live Project:</h3>
                    <a href="#" class="default-btn">View Project</a>
                </li>
            </ul>
        </div>
    </section>
    <!--/.project-info-->

    <section class="project-details padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="project-thumb">
                        <img src="https://kidsloveqatar.com/wp-content/uploads/2026/01/Fly-Over-Wonders-4.webp" alt="Flying Cinema">
                    </div>
                    <div class="project-details-content">
                        <h2 class="mt-30">Soar Above The World</h2>
                        <p>The Flying Cinema is an advanced motion-based theater that lifts the audience into the air, perfectly synchronized with a massive curved screen. It simulates the sensation of soaring through majestic landscapes.</p>
                        <p>Designed for maximum immersion, this attraction incorporates multi-axis motion and environmental effects like wind and mist, establishing itself as a premier attraction for any theme park or mall.</p>
                        <div class="overview-wrap">
                            <div>
                                <h3>Overview:</h3>
                                <ul class="overview-list">
                                    <li>Synchronized motion seating</li>
                                    <li>Massive curved projection screen</li>
                                    <li>Wind and mist sensory effects</li>
                                    <li>Immersive high-altitude simulations</li>
                                </ul>
                            </div>
                            <div>
                                <h3>Challenge:</h3>
                                <ul class="overview-list">
                                    <li>Complex hydraulic motion syncing</li>
                                    <li>Safety protocols for suspended seating</li>
                                    <li>High-definition wide field-of-view rendering</li>
                                    <li>Seamless environmental effect timing</li>
                                </ul>
                            </div>
                        </div>
                        <ul class="post-details-gallery">
                            <li><img src="{{ asset("assets/img/post-1.jpg") }}" alt="img"></li>
                            <li><img src="{{ asset("assets/img/post-2.jpg") }}" alt="img"></li>
                        </ul>
                        <h2 class="mt-30">Solution And Results:</h2>
                        <p>The execution of the Flying Cinema provided an unparalleled thrill for mall-goers at the Mall of Qatar. It seamlessly integrated the feeling of flight with impeccable cinematic quality, drawing widespread acclaim and a massive surge in daily visitors.</p>
                        <ul class="project-social">
                            <li>Share This Project:</li>
                            <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                            <li><a href="#"><i class="lab la-twitter"></i></a></li>
                            <li><a href="#"><i class="lab la-youtube"></i></a></li>
                            <li><a href="#"><i class="lab la-behance"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/.project-details-->

    <section class="project-section bg-grey padding">
        <div class="bg-pattern"></div>
        <div class="container">
            <div class="section-heading-wrap mb-40">
                <div class="section-heading">
                    <h3>our projects</h3>
                    <h2>Related <span>projects</span></h2>
                    <p>Discover other exciting attractions we have built <br>for clients across the globe.</p>
                </div>
                <a class="default-btn" href="{{ url('/projects') }}">View All Project</a>
            </div>
            <div class="swiper-outside">
                <div class="project-carousel">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="200ms">
                                <div class="project-thumb">
                                    <a class="venobox project-view" href="{{ asset("assets/img/project-1.jpg") }}"><img src="{{ asset("assets/img/project-1.jpg") }}" alt="img"></a>
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Architecture</a>
                                    <h3><a href="{{ url('/project-details') }}">The Hagia Sophia Istanbul Turkey</a></h3>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="400ms">
                                <div class="project-thumb">
                                    <img src="{{ asset("assets/img/project-2.jpg") }}" alt="img">
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Building</a>
                                    <h3><a href="{{ url('/project-details') }}">Le Centre Pompidou Paris France</a></h3>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="project-item wow fade-in-bottom" data-wow-delay="600ms">
                                <div class="project-thumb">
                                    <img src="{{ asset("assets/img/project-3.jpg") }}" alt="img">
                                </div>
                                <div class="project-content">
                                    <a href="{{ url('/projects') }}" class="category">Construction</a>
                                    <h3><a href="{{ url('/project-details') }}">Metropol Cathedral of Brasília</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-pagination"></div><!-- Carousel Dots -->
                </div>
                <!-- Carousel Arrows -->
                <div class="swiper-nav swiper-next"><i class="las la-long-arrow-alt-right"></i></div>
                <div class="swiper-nav swiper-prev"><i class="las la-long-arrow-alt-left"></i></div>
            </div>
        </div>
    </section>
    <!--/.project-section-->

   <footer class="footer-section">
            <div class="container">
                <div class="row footer-area">
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <a class="footer-logo" href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="logo"></a>
                            <p>Our success in creating business solutions is due in part spacially to talented committed team.</p>
                            <ul class="footer-social">
                                <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                <li><a href="#"><i class="lab la-youtube"></i></a></li>
                                <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Company</h3>
                            <ul class="footer-list">
                                <li><a href="{{ url('/about') }}">About Us</a></li>
                                <li><a href="{{ url('/contact') }}">Get in Touch</a></li>
                                <li><a href="{{ url('/faqs') }}">Help &amp; Faqs</a></li>
                                <li><a href="{{ url('/faqs') }}">Privacy Policy</a></li>
                                <li><a href="{{ url('/contact') }}">Support</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Information</h3>
                            <ul class="footer-list">
                                <li>
                                    <p>A.M.A Arcade, Vallathol Junction, 4/1585, Seaport - Airport Rd, P.O, Thrikkakara, Front, Kochi, Kakkanad, Kerala 682021</p>
                                </li>
                                <li><a href="tel:7025777755">+91 7025 777 755</a></li>
                                <li><a href="#">info@agelessind.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 sm-padding">
                        <div class="footer-widget">
                            <h3>Subscribe Newslatters</h3>
                            <form action="php/mailchimp-subscribe.php" id="ajax_mc_form" class="subscribe-form">
                                <div class="mc-fields">
                                    <input id="mc_email" class="form-control" type="email" name="mc_email" placeholder="Your Email" required>
                                    <button class="submit"><i class="las la-long-arrow-alt-right"></i></button>
                                </div>
                                <div class="clearfix"></div>
                                <div id="mc-form-messages" class="alert" role="alert"></div>
                            </form>
                            <p>Subscribe us and get all the benifits from today.</p>
                        </div>
                    </div>
                </div>
                <div class="copyright-text">
                    © <span id="currentYear"></span> Ageless Entertainments All Rights Reserved.</a>
                </div>
            </div>
    </footer>
    <!--/.footer-section-->

    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>
    <!--/.scrollup-->

    <!--jQuery Lib-->
    <script src="{{ asset("assets/js/vendor/jquary-3.6.0.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/bootstrap.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/popper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/odometer.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/jquery.nice-select.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/waypoints.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/venobox.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/swiper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/smooth-scroll.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/wow.min.js") }}"></script>
    <script src="{{ asset("assets/js/mailchimp.js") }}"></script>
    <script src="{{ asset("assets/js/main.js") }}"></script>

</body>
</html>