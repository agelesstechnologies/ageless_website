<!doctype html>
    <html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Buildex Construction and Building HTML5 Template">
        <meta name="author" content="ThemeEaster">

        <title>Agelessindia</title>

        <link rel="shortcut icon" type="image/x-icon" href="{{ asset("assets/img/favicon.png") }}">

        <link rel="stylesheet" href="{{ asset("assets/css/bootstrap.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/animate.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/keyframe-animation.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/line-awesome.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/construction-icons.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/odometer.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/nice-select.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/swiper.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/venobox.min.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/slider.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/common-style.css") }}">
        <link rel="stylesheet" href="{{ asset("assets/css/main.css") }}">

    </head>

    <body>
        

        <div class="site-preloader">
            <div class="spinner"></div>
        </div>
        <!-- Site Preloader -->

          <header class="main-header">
            <div class="container">
                <div class="main-header-wapper">
                    <div class="site-logo">
                        <a href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="Logo"></a>
                    </div>
                    <div class="main-header-info">
                        <div class="top-header">
                            <ul class="top-left">
                                <li><i class="las la-phone-volume"></i><a href="tel:+917025777755">+91 7025 777 755</a></li>
                                <li><i class="las la-envelope-open"></i>info@agelessind.com</li>
                            </ul>
                            <div class="top-right">
                                <ul class="top-header-nav">
                                    <li><a href="{{ url('/faq') }}">FAQ</a></li>
                                </ul>
                                <ul class="header-social-share">

                                    <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="lab la-instagram"></i></a></li>
                                    <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
                                    <li><a href="#"><i class="lab la-whatsapp"></i></a></li>

                                </ul>
                            </div>
                        </div>
                        <!--/.top-header-->
                        <div class="header-menu-wrap">
                            <ul class="nav-menu">
                                <li>
                                    <a href="{{ url('/') }}">Home</a>
                                </li>
                                <li>
                                    <a href="{{ url('/about-company') }}">About Us</a>
                                </li>
                                
                                <li>
                                    <a href="{{ url('/projects') }}">Projects</a>
                                    
                                </li>
                                <li>
                                    <a href="{{ url('/products') }}">Products</a>
                                    
                                </li>
                                <li class="dropdown_menu">
                                    <a href="{{ route('blog.index') }}">Blog</a>
                                </li>
                                <li><a href="{{ url('/contact') }}">Contact</a></li>
                            </ul>
                            <div class="menu-right-item">
                                <div class="mobile-menu-icon">
                                    <div class="burger-menu">
                                        <div class="line-menu line-half first-line"></div>
                                        <div class="line-menu"></div>
                                        <div class="line-menu line-half last-line"></div>
                                    </div>
                                </div>
                         
                            </div>
                        </div>
                        <!--/.header-menu-wrap-->
                    </div>
                </div>
            </div>
        </header>
<!--/.main-header-->

    <div id="popup-search-box">
        <div class="box-inner-wrap d-flex align-items-center">
            <form id="form" action="#" method="get" role="search">
                <input id="popup-search" type="text" name="s" placeholder="Type keywords here...">
                <button id="popup-search-button" type="submit" name="submit">
                    <i class="las la-search"></i>
                </button>
            </form>
            <div class="search-close"><i class="las la-times"></i></div>
        </div>
    </div>
    <!--/.popupsearch-box-->
    <div id="searchbox-overlay"></div>
    <div class="map-wrapper">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.3232337726885!2d76.3537588!3d10.0023356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080d207f93e06b%3A0xc20a554f4ee18ced!2sAgeless%20Entertainments%2C%20Kakkanad%2C%20Kerala!5e0!3m2!1sen!2sin!4v0000000000000!5m2!1sen!2sin" 
            width="100%" 
            height="400" 
            frameborder="0" 
            style="border:0;" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
    <section class="contact-section padding">
        <div class="map-pattern"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 sm-padding">
                    <div class="contact-info">
                        <div class="contact-heading">
                            <h2>Get In Touch</h2>
                            <p>Our success in creating business solutions is due in large part spacially <br> to talented and highly committed team.</p>
                        </div>
                        <ul class="contact-details">
                            <li><i class="las la-map-marked-alt"></i>A.M.A Arcade, Vallathol Junction, Seaport - Airport Rd,
                                <br>Thrikkakara, Kakkanad, Kochi, Kerala 682021</li>
                            <li><i class="las la-envelope-open"></i>info@agelessind.com<br>Sales@agelessind.com</li>
                            <li><i class="las la-phone-volume"></i>+91 702 5777 755 </li>
                        </ul>
                    </div>
                </div>
               <div class="col-lg-6 sm-padding">
                <div class="contact-form-wrap">
                    <div class="contact-heading">
                    <h2>Fill Up The Form</h2>
                    
                    </div>

                    <div class="contact-form">
                   <form id="ajax_contact" class="form-horizontal"
    action="{{ route('contact.submit') }}"
    method="POST">
    @csrf

    <div class="contact-form-group">
        <div class="form-field">
            <input type="text" id="firstname" name="firstname" class="form-control" placeholder="First Name" required>
        </div>

        <div class="form-field">
            <input type="text" id="lastname" name="lastname" class="form-control" placeholder="Last Name" required>
        </div>

        <div class="form-field">
            <input type="email" id="email" name="email" class="form-control" placeholder="Email" required>
        </div>

        <div class="form-field">
            <input type="text" id="phone" name="phone" class="form-control" placeholder="Phone Number" required>
        </div>

        <div class="form-field message">
            <textarea id="message" name="message" cols="30" rows="4" class="form-control" placeholder="Message" required></textarea>
        </div>

        <div class="form-field submit-btn">
            <button id="submit" class="default-btn" type="submit">Send Message</button>
        </div>
    </div>

    @if(session('success'))
        <div id="form-messages" class="ajax-form-msg alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @else
        <div id="form-messages" class="ajax-form-msg alert" role="alert"></div>
    @endif
</form>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
    <!--/.contact-section-->

    <footer class="footer-section">
        <div class="container">
            <div class="row footer-area">
                <div class="col-lg-3 col-sm-6 sm-padding">
                    <div class="footer-widget">
                        <a class="footer-logo" href="{{ url('/') }}"><img src="{{ asset("assets/img/nlogo.png") }}" alt="logo"></a>
                        <p>Our success in creating business solutions is due in part spacially to talented committed team.</p>
                        <ul class="footer-social">
                            <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
                            <li><a href="#"><i class="lab la-twitter"></i></a></li>
                            <li><a href="#"><i class="lab la-youtube"></i></a></li>
                            <li><a href="#"><i class="lab la-behance"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding">
                    <div class="footer-widget">
                        <h3>Company</h3>
                        <ul class="footer-list">
                            <li><a href="{{ url('/about') }}">About Us</a></li>
                            <li><a href="{{ url('/contact') }}">Get in Touch</a></li>
                            <li><a href="{{ url('/faqs') }}">Help &amp; Faqs</a></li>
                            <li><a href="{{ url('/faqs') }}">Privacy Policy</a></li>
                            <li><a href="{{ url('/contact') }}">Support</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding">
                    <div class="footer-widget">
                        <h3>Information</h3>
                        <ul class="footer-list">
                            <li>
                                <p>1st Floor Confident Gem Rajagiri Valley Kakkanad Kochi-682039</p>
                            </li>
                            <li><a href="tel:7025777755">+91 7025 777 755</a></li>
                            <li><a href="#">info@agelessind.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding">
                    <div class="footer-widget">
                        <h3>Subscribe Newslatters</h3>
                        <form action="php/mailchimp-subscribe.php" id="ajax_mc_form" class="subscribe-form">
                            <div class="mc-fields">
                                <input id="mc_email" class="form-control" type="email" name="mc_email" placeholder="Your Email" required>
                                <button class="submit"><i class="las la-long-arrow-alt-right"></i></button>
                            </div>
                            <div class="clearfix"></div>
                            <div id="mc-form-messages" class="alert" role="alert"></div>
                        </form>
                        <p>Subscribe us and get all the benifits from today.</p>
                    </div>
                </div>
            </div>
            <div class="copyright-text">
                © <span id="currentYear"></span> Ageless Entertainments All Rights Reserved.</a>
            </div>
        </div>
    </footer>
    <!--/.footer-section-->

    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>
    
    <!--/.scrollup-->
<!-- SweetAlert2 library for popups -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
const form = document.getElementById("ajax_contact");
const msg = document.getElementById("form-messages");
const submitBtn = document.getElementById("submit");

form.addEventListener("submit", (e) => {
  e.preventDefault(); // stops double submission

  // Change button text to show it's sending
  submitBtn.disabled = true;
  submitBtn.innerHTML = "⏳ Sending...";
  msg.textContent = "";
  
  const formData = new FormData(form);

  fetch(form.action, { method: "POST", body: formData })
    .then((res) => {
      if (res.ok) {
        // SweetAlert2 success popup
        Swal.fire({
          icon: "success",
          title: "Message Sent!",
          text: "Your message has been successfully submitted.",
          showConfirmButton: false,
          timer: 2000
        });

        form.reset();
      } else {
        Swal.fire({
          icon: "error",
          title: "Failed!",
          text: "Could not send. Please check script permissions."
        });
      }
    })
    .catch(() => {
      Swal.fire({
        icon: "error",
        title: "Network Error",
        text: "Please check your internet connection and try again!"
      });
    })
    .finally(() => {
      // Restore button state
      submitBtn.disabled = false;
      submitBtn.innerHTML = "Send Message";
    });
});
</script>


    <!--jQuery Lib-->
    <script src="{{ asset("assets/js/vendor/jquary-3.6.0.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/bootstrap.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/popper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/odometer.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/jquery.nice-select.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/waypoints.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/venobox.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/swiper.min.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/smooth-scroll.js") }}"></script>
    <script src="{{ asset("assets/js/vendor/wow.min.js") }}"></script>
    
    <script src="{{ asset("assets/js/main.js") }}"></script>

</body>

</html>
