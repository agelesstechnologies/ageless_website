@extends('admin.layout')

@section('content')
<div class="card p-4">
    <h3>Add Project</h3>

    <form method="POST" action="{{ route('admin.projects.store') }}" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label>Project Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <input type="text" name="category" class="form-control">
        </div>

        <div class="mb-3">
            <label>Project Image</label>
            <input type="file" name="image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Short Description</label>
            <textarea name="short_description" class="form-control" rows="3"></textarea>
        </div>

        <div class="mb-3">
            <label>Full Description</label>
            <textarea name="description" class="form-control" rows="6"></textarea>
        </div>

        <button class="btn btn-primary">Save Project</button>
        <a href="{{ route('admin.projects.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection