@extends('admin.layout')

@section('content')
<div class="card p-4">
    <h3>Edit Product</h3>

    <form method="POST" action="{{ route('admin.products.update', $product) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Product Name</label>
            <input type="text" name="name" class="form-control" value="{{ $product->name }}" required>
        </div>

        <div class="mb-3">
            <label>Current Image</label><br>
            @if($product->image)
                <img src="{{ asset('storage/'.$product->image) }}" width="150" class="mb-2">
            @endif
            <input type="file" name="image" class="form-control">
        </div>

        <div class="mb-3">
            <label>Short Description</label>
            <textarea name="short_description" class="form-control" rows="3">{{ $product->short_description }}</textarea>
        </div>

        <div class="mb-3">
            <label>Full Description</label>
            <textarea name="description" class="form-control" rows="6">{{ $product->description }}</textarea>
        </div>

        <div class="mb-3">
            <label>Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="{{ $product->sort_order }}">
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control">
                <option value="1" {{ $product->status ? 'selected' : '' }}>Active</option>
                <option value="0" {{ !$product->status ? 'selected' : '' }}>Inactive</option>
            </select>
        </div>

        <button class="btn btn-primary">Update Product</button>
        <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection