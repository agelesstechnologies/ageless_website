@extends('layouts.app')

@section('content')

<style>
    .page-header {
        padding: 60px 0 30px !important;
        min-height: auto !important;
        height: auto !important;
    }

    .blog-section.padding {
        padding-top: 40px !important;
    }

    .post-thumb img {
        width: 100%;
        height: 260px;
        object-fit: cover;
        display: block;
    }
</style>

<section class="page-header">
    <div class="container">
        <div class="page-header-info">
            <h4>News & Articles</h4>
            <h2 style="color:black;">Our Blog</h2>
        </div>
    </div>
</section>

<section class="blog-section padding">
    <div class="container">
        <div class="row">
            @forelse($blogs as $blog)
                <div class="col-lg-4 col-md-6 sm-padding">
                    <div class="post-card">
                        @if($blog->image)
                            <div class="post-thumb">
                                <img src="{{ asset('storage/'.$blog->image) }}" alt="{{ $blog->title }}">
                            </div>
                        @endif

                        <div class="post-content-wrap">
                            <ul class="post-meta">
                                <li>
                                    <i class="las la-calendar"></i>
                                    {{ optional($blog->published_at)->format('d M Y') }}
                                </li>
                            </ul>

                            <div class="post-content">
                                <h3>
                                    <a href="{{ route('blog.show', $blog->slug) }}">
                                        {{ $blog->title }}
                                    </a>
                                </h3>

                                <p>{{ $blog->excerpt }}</p>

                                <a href="{{ route('blog.show', $blog->slug) }}" class="read-more">
                                    Read More
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12">
                    <p>No blog posts available.</p>
                </div>
            @endforelse
        </div>

        <div class="mt-4">
            {{ $blogs->links() }}
        </div>
    </div>
</section>

@endsection