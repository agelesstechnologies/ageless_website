@extends('layouts.app')

@section('content')



<section class="project-section padding">
    <div class="container">
        <div class="row gy-4">
            @forelse($projects as $project)
                <div class="col-lg-4 col-md-6">
                    <a href="{{ route('projects.show', $project->slug) }}" class="project-item d-block">
                        <div class="project-thumb">
                            @if($project->image)
                                <img src="{{ asset('storage/'.$project->image) }}" alt="{{ $project->title }}">
                            @endif
                        </div>

                        <div class="project-content">
                            @if($project->category)
                                <span class="category">{{ $project->category }}</span>
                            @endif

                            <h3>{{ $project->title }}</h3>
                            <p>{{ $project->short_description }}</p>
                        </div>
                    </a>
                </div>
            @empty
                <div class="col-12">
                    <p>No projects available.</p>
                </div>
            @endforelse
        </div>
    </div>
</section>

@endsection