@extends('layouts.app')

@section('content')

<style>
    .project-detail-wrap {
        padding: 90px 0;
        background: #f8f9fb;
    }

    .project-detail-card {
        background: #fff;
        border-radius: 22px;
        overflow: hidden;
        box-shadow: 0 15px 45px rgba(0,0,0,.08);
    }

    .project-detail-img img {
        width: 100%;
        height: 480px;
        object-fit: cover;
        display: block;
    }

    .project-detail-content {
        padding: 45px;
    }

    .project-category {
        display: inline-block;
        background: #ff9800;
        color: #fff;
        padding: 7px 16px;
        border-radius: 30px;
        font-size: 14px;
        font-weight: 700;
        margin-bottom: 18px;
    }

    .project-detail-content h1 {
        font-size: 42px;
        font-weight: 800;
        margin-bottom: 18px;
        color: #111827;
    }

    .short-desc {
        font-size: 18px;
        color: #555;
        line-height: 1.8;
        margin-bottom: 28px;
    }

    .full-desc {
        color: #444;
        line-height: 1.9;
        font-size: 16px;
        border-top: 1px solid #eee;
        padding-top: 28px;
    }

    .project-actions {
        margin-top: 35px;
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
    }

    .project-btn {
        display: inline-block;
        padding: 13px 28px;
        border-radius: 40px;
        background: #ff9800;
        color: #fff;
        font-weight: 700;
        text-decoration: none;
        transition: .3s;
    }

    .project-btn:hover {
        background: #111827;
        color: #fff;
        transform: translateY(-3px);
    }

    .project-btn.dark {
        background: #111827;
    }

    .project-btn.dark:hover {
        background: #ff9800;
    }

    @media(max-width: 768px) {
        .project-detail-img img {
            height: 280px;
        }

        .project-detail-content {
            padding: 28px;
        }

        .project-detail-content h1 {
            font-size: 30px;
        }
    }
</style>



<section class="project-detail-wrap">
    <div class="container">
        <div class="project-detail-card">

            @if($project->image)
                <div class="project-detail-img">
                    <img src="{{ asset('storage/'.$project->image) }}" alt="{{ $project->title }}">
                </div>
            @endif

            <div class="project-detail-content">
                @if($project->category)
                    <span class="project-category">{{ $project->category }}</span>
                @endif

                <h1>{{ $project->title }}</h1>

                @if($project->short_description)
                    <p class="short-desc">{{ $project->short_description }}</p>
                @endif

                @if($project->description)
                    <div class="full-desc">
                        {!! nl2br(e($project->description)) !!}
                    </div>
                @endif

                <div class="project-actions">
                    <a href="{{ url('/contact') }}" class="project-btn">Enquire Now</a>
                    <a href="{{ route('projects.index') }}" class="project-btn dark">Back to Projects</a>
                </div>
            </div>

        </div>
    </div>
</section>

@endsection